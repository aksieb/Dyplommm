<?php

namespace App\Http\Controllers;

class CartController extends Controller
{
}
