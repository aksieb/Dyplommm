<ul class="list-unstyled components">
    <li>
        <a href=<?php echo e(url('/dashboard')); ?>>Panel</a>
    </li>
    <li>
        <a href=<?php echo e(url('/dashboard/categories')); ?>>Kategorie</a>
    </li>
    <li>
        <a href=<?php echo e(url('/dashboard/attributes')); ?>>Atrybuty</a>
    </li>
    <li>
        <a href=<?php echo e(url('/dashboard/products')); ?>>Produkty</a>
    </li>
    <li>
        <a href=<?php echo e(url('/dashboard/orders')); ?>>Zamówienia</a>
    </li>
    <li>
        <a href="#userSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><?php echo e(Auth::user()->email); ?></a>
        <ul class="collapse list-unstyled" id="userSubmenu">
            <li>
                <a href=<?php echo e(url('/logout')); ?>>Wyloguj</a>
            </li>
        </ul>
    </li>
</ul>
<?php /**PATH C:\xampp\htdocs\resources\views/dashboard/sidebar.blade.php ENDPATH**/ ?>