<?php $__env->startSection('stylesheets'); ?>
    <link rel='stylesheet' href=<?php echo e(asset('/assets/css/shop-item.css')); ?> />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.components.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">

        <div class="row">

        <?php echo $__env->make('front.components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="col-lg-9">

        <div class="carda">

<!--Section: Products v.3-->
<section class="text-center mb-4">

    <!--Grid row-->
    <div class="row wow fadeIn">

      <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-6 mb-4 mt-4">

            <!--Card-->
            <div class="card">

            <!--Card image-->
            <?php $__currentLoopData = $product->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="view overlay">
                    <img src=<?php echo e(url($file->filename)); ?> class="card-img-top" alt="">
                    <a>
                    <div class="mask rgba-white-slight"></div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!--Card image-->

            <!--Card content-->
            <div class="card-body text-center">
                <!--Category & Title-->
                <a href="" class="grey-text">

                <h5><strong><?php echo e($product->name); ?></strong></h5>

                </a>
                <h5>

                    <button type="button" class="btn btn-secondary btn-sm">Do koszyka</button>

                </h5>

                <h4 class="font-weight-bold blue-text">
                <strong><?php echo e($product->price()); ?>zł</strong>
                </h4>

            </div>
            <!--Card content-->

            </div>
            <!--Card-->

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <!--Fourth column-->

    </div>
    <!--Grid row-->

  </section>
      <!-- /.col-lg-9 -->
  <!--Pagination-->
  <nav class="d-flex justify-content-center wow fadeIn">
    <ul class="pagination pg-blue">

      <!--Arrow left-->
      <li class="page-item disabled">
        <a class="page-link" href="#" aria-label="Previous">
          <span aria-hidden="true">&laquo;</span>
          <span class="sr-only">Previous</span>
        </a>
      </li>

      <li class="page-item active">
        <a class="page-link" href="#">1
          <span class="sr-only">(current)</span>
        </a>
      </li>
      <li class="page-item">
        <a class="page-link" href="#">2</a>
      </li>
      <li class="page-item">
        <a class="page-link" href="#">3</a>
      </li>
      <li class="page-item">
        <a class="page-link" href="#">4</a>
      </li>
      <li class="page-item">
        <a class="page-link" href="#">5</a>
      </li>

      <li class="page-item">
        <a class="page-link" href="#" aria-label="Next">
          <span aria-hidden="true">&raquo;</span>
          <span class="sr-only">Next</span>
        </a>
      </li>
    </ul>
  </nav>
  <!--Pagination-->
    </div>


  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="foot">

      <p class="m-0 text-center text-white">Informacje o sklepie (adres, zwroty, kontakt)</p>

    <!-- /.container -->
  </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/front/category.blade.php ENDPATH**/ ?>