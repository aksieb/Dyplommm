<div class='form-group'>
    <label for='name'>Klucz</label>
    <select
        name="keys[]"
        class='form-control attribute-choose'
    >
        <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option
                value=<?php echo e($attr->id); ?>

                data-unit=<?php echo e($attr->unit); ?>

                <?php if(isset($attribute)): ?> <?php if($attr->id == $attribute->attribute_id): ?> selected='selected' <?php endif; ?> <?php endif; ?>
            ><?php echo e($attr->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<?php /**PATH S:\courses\kasia_beska\a4\resources\views/dashboard/products/attribute.blade.php ENDPATH**/ ?>