<?php $__env->startSection('right_box'); ?>
    <div class='row'>
        <div class='col-sm-12'>
            <nav aria-label="breadcrumb mb-2">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href=<?php echo e(url('/dashboard')); ?>>Panel</a></li>
                    <?php if(isset($id)): ?>
                        <li class="breadcrumb-item" aria-current="page"><a href=<?php echo e(url('/dashboard/categories')); ?>>Kategorie</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($id); ?></li>
                    <?php else: ?>
                        <li class="breadcrumb-item active">Kategorie</li>
                    <?php endif; ?>
                </ol>
            </nav>

            <?php if(isset($id)): ?>
                <a href=<?php echo e(url('/dashboard/category?category_id=' . $id)); ?> class='btn btn-primary mb-3'>Dodaj</a>
            <?php else: ?>
                <a href=<?php echo e(url('/dashboard/category')); ?> class='btn btn-primary mb-3'>Dodaj</a>
            <?php endif; ?>

            <?php if(session('success')): ?>
                <div class="alert alert-success mb-3">
                    <?php echo e(session('success_msg')); ?>

                </div>
            <?php endif; ?>

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nazwa</th>
                        <th scope="col">Akcje</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($category->id); ?></th>
                            <td><?php echo e($category->name); ?></td>
                            <td>
                                <a
                                    href=<?php echo e(url('/dashboard/category/' . $category->id)); ?>

                                    class='btn btn-primary'
                                >Edytuj</a>

                                <?php if(empty($id)): ?>
                                    <a
                                        href=<?php echo e(url('/dashboard/categories/' . $category->id)); ?>

                                        class='btn btn-primary'
                                    >Podkategorie</a>
                                <?php endif; ?>

                                <a
                                    href=<?php echo e(url('/dashboard/products?category_id=' . $category->id)); ?>

                                    class='btn btn-primary'
                                >Produkty</a>

                                <a
                                    href=<?php echo e(url('/dashboard/product?category_id=' . $category->id)); ?>

                                    class='btn btn-primary'
                                >Dodaj produkt</a>

                                <a
                                    href=<?php echo e(url('/dashboard/category/' . $category->id . '/delete')); ?>

                                    class='btn btn-danger record-delete'
                                >Usuń</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <th scope='row' colspan='6' class='text-center'>Brak rekordów</th>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php echo e($categories->appends(array(

            ))->links('pagination::bootstrap-4')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('.record-delete').on('click', function() {
            return confirm("Jesteś pewien? Usunięte zostaną wszystkie kategorie!");
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\courses\kasia_beska\a4\resources\views/dashboard/categories/index.blade.php ENDPATH**/ ?>