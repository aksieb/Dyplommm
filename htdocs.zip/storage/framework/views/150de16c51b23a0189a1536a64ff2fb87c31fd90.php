<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Sklep internetowy</title>

        <link rel='stylesheet' href=<?php echo e(asset('/assets/css/bootstrap.min.css')); ?> />
        <link rel='stylesheet' href=<?php echo e(asset('/assets/css/app.css')); ?> />
    </head>

    <body>
        <div class='container'>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <script src=<?php echo e(asset('/assets/js/jquery.min.js')); ?>></script>
        <script src=<?php echo e(asset('/assets/js/popper.min.js')); ?>></script>
        <script src=<?php echo e(asset('/assets/js/bootstrap.bundle.min.js')); ?>></script>

        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH S:\courses\kasia_beska\a4\resources\views/app.blade.php ENDPATH**/ ?>